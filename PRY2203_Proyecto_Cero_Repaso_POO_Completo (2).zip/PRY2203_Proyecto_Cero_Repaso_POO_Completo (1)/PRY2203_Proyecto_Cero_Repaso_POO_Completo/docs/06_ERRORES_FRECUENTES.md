# 06 — Errores frecuentes

## 1. Confundir clase con objeto

Incorrecto conceptualmente:

```text
Producto es el objeto.
```

Correcto:

```text
Producto es la clase.
producto1 es una referencia a un objeto Producto.
```

---

## 2. Dejar todos los atributos `public`

Evita:

```java
public int edad;
```

Prefiere:

```java
private int edad;
```

y controla el acceso.

---

## 3. Confundir sobrecarga con sobrescritura

Sobrecarga:

```java
procesar()
procesar(String dato)
```

Sobrescritura:

```java
@Override
public void procesar()
```

en una clase hija.

---

## 4. Cambiar solo el retorno

Esto NO es una sobrecarga válida:

```java
int calcular()
double calcular()
```

Java necesita distinguir los métodos por sus parámetros.

---

## 5. Usar herencia para todo

Pregunta:

```text
¿realmente existe una relación ES UN?
```

Si la relación es:

```text
TIENE UN
```

probablemente estás pensando en composición.

---

## 6. Crear una interfaz que nadie usa

No basta con que exista:

```java
interface X
```

Debe existir una clase que la implemente y el sistema debe utilizar ese comportamiento.

---

## 7. Crear clases pero no integrarlas

Tener:

```java
Libro.java
```

no demuestra nada si `Main` nunca crea ni utiliza un `Libro`.

---

## 8. Confundir commit con push

```text
commit = historial local
push   = envío al remoto
```

---

## 9. Main hace todo

Si `Main`:

- crea;
- valida;
- busca;
- calcula;
- almacena;
- imprime;
- modifica;

entonces probablemente tiene demasiadas responsabilidades.

---

## 10. "Compila" = "está correcto"

No.

Debes comprobar:

- entradas;
- ejecución;
- resultados;
- casos distintos;
- relaciones entre clases.
