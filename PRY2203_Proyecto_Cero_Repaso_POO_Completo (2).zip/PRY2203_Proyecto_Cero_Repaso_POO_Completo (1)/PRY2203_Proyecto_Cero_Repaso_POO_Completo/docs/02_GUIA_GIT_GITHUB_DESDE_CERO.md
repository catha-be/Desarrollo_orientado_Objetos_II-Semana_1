# 02 — Git y GitHub desde cero

## Idea principal

Git y GitHub no son lo mismo.

**Git** registra cambios en tu computador.

**GitHub** permite publicar un repositorio Git en Internet.

Flujo:

```text
Programar
   ↓
Guardar
   ↓
git status
   ↓
git add
   ↓
git commit
   ↓
git push
   ↓
GitHub
```

---

# Parte A — Antes del primer commit

## 1. Comprobar Git

En PowerShell:

```powershell
git --version
```

## 2. Configurar identidad

Solo es necesario hacerlo una vez en el computador:

```powershell
git config --global user.name "Nombre Apellido"
git config --global user.email "correo@ejemplo.cl"
```

Comprobar:

```powershell
git config --global user.name
git config --global user.email
```

---

# Parte B — Crear el repositorio local

Ubícate en la carpeta del proyecto:

```powershell
cd "RUTA\PRY2203-Repaso-POO"
```

Inicializa Git:

```powershell
git init
```

Revisa:

```powershell
git status
```

### ¿Qué acabamos de hacer?

`git init` creó un repositorio Git local.

Todavía NO hemos enviado nada a GitHub.

---

# Parte C — `.gitignore`

Antes del primer commit crea:

```text
.gitignore
```

Ejemplo:

```gitignore
*.class
out/
build/
target/
.idea/
*.iml
.env
.DS_Store
Thumbs.db
```

Nunca ignores:

```text
src/
```

porque allí está tu código fuente.

Nunca publiques:

- contraseñas;
- tokens;
- credenciales;
- claves privadas;
- archivos `.env` con secretos.

---

# Parte D — Primer commit

## 1. Ver cambios

```powershell
git status
```

## 2. Preparar archivos

```powershell
git add .
```

## 3. Volver a revisar

```powershell
git status
```

Ahora los archivos deberían aparecer preparados para el commit.

## 4. Crear el primer commit

```powershell
git commit -m "Estructura inicial del proyecto de repaso POO"
```

### ¿Qué es un commit?

Un commit es un punto de control del proyecto.

No es lo mismo que guardar un archivo.

No es lo mismo que hacer push.

---

# Parte E — Crear repositorio en GitHub

En GitHub crea un repositorio.

Nombre sugerido:

```text
PRY2203-Repaso-POO
```

La visibilidad dependerá de lo que necesites.

Si una actividad oficial exige repositorio público, debe respetarse esa instrucción.

Para este proyecto de práctica puedes elegir según el uso que le darás.

---

# Parte F — Conectar Git local con GitHub

Copia la URL de tu repositorio.

Ejemplo:

```text
https://github.com/USUARIO/PRY2203-Repaso-POO.git
```

Configura el remoto:

```powershell
git remote add origin https://github.com/USUARIO/PRY2203-Repaso-POO.git
```

Comprobar:

```powershell
git remote -v
```

---

# Parte G — Rama principal

```powershell
git branch -M main
```

---

# Parte H — Primer push

```powershell
git push -u origin main
```

Después del primer `push -u`, normalmente podrás utilizar:

```powershell
git push
```

para los siguientes envíos.

---

# Commit no es Push

```text
git commit
   ↓
el cambio queda registrado localmente

git push
   ↓
los commits son enviados al repositorio remoto
```

---

# Flujo normal después del primer push

Modificas código.

Luego:

```powershell
git status
git add .
git commit -m "Agregado ejemplo de encapsulamiento"
git push
```

Más adelante:

```powershell
git add .
git commit -m "Agregados ejemplos de herencia y polimorfismo"
git push
```

---

# Historial pedagógico sugerido

```text
Commit 1 - Estructura inicial del proyecto
Commit 2 - Clase, objeto y encapsulamiento
Commit 3 - Composición y herencia
Commit 4 - Sobrecarga y sobrescritura
Commit 5 - Polimorfismo
Commit 6 - Clase abstracta y Template Method
Commit 7 - Interfaces
Commit 8 - Strategy
Commit 9 - Proyecto integrador
Commit 10 - Documentación y pruebas finales
```

Evita commits como:

```text
cosas
todo
final
final2
ahora_si
```

---

# Lo mismo desde IntelliJ

Puedes utilizar:

```text
VCS → Enable Version Control Integration → Git
```

Luego la ventana:

```text
Commit
```

y después:

```text
Git → Push
```

El principio es exactamente el mismo:

```text
Commit = historial local
Push   = publicar commits en el remoto
```

---

# Comprobación final

Abre GitHub y verifica:

- aparecen los `.java`;
- aparece `src`;
- el último commit es visible;
- el enlace abre correctamente;
- el historial muestra una evolución lógica.

No te quedes solamente con el mensaje:

```text
Push successful
```

Comprueba el repositorio realmente.
