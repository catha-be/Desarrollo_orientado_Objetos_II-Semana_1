# 05 — Ejercicios incrementales

## Nivel 1 — Clase y objeto

Crea:

```java
class Curso
```

con:

```text
codigo
nombre
```

Después crea dos objetos desde un `Main`.

---

## Nivel 2 — Encapsulamiento

Convierte los atributos en `private`.

Agrega:

- constructor;
- getters;
- setters;
- `toString()`.

Pregunta:

> ¿Qué problema evita impedir el acceso directo a los atributos?

---

## Nivel 3 — Composición

Crea:

```java
Profesor
```

Luego haz que:

```java
Curso TIENE UN Profesor
```

No utilices herencia.

Pregunta:

> ¿Por qué esta relación es composición y no herencia?

---

## Nivel 4 — Herencia

Crea una clase base:

```java
Material
```

y clases:

```java
Apunte
Video
```

Pregunta:

> ¿Qué datos deberían estar en la clase padre y cuáles deberían pertenecer solo a cada hija?

---

## Nivel 5 — Sobrecarga

En `Material`, crea:

```java
buscar(String nombre)
buscar(int id)
```

Explica por qué eso es sobrecarga.

---

## Nivel 6 — Sobrescritura

Define:

```java
mostrarDetalle()
```

en la clase padre.

Haz que las hijas lo redefinan utilizando:

```java
@Override
```

---

## Nivel 7 — Polimorfismo

Crea:

```java
Material[] materiales
```

y almacena objetos `Apunte` y `Video`.

Ejecuta:

```java
material.mostrarDetalle();
```

Pregunta:

> ¿Cómo sabe Java qué implementación ejecutar?

---

## Nivel 8 — Clase abstracta

Convierte:

```java
Material
```

en abstracta.

Agrega:

```java
abstract void validar();
```

---

## Nivel 9 — Interfaces

Crea:

```java
Descargable
```

con:

```java
void descargar();
```

Decide qué clases deberían implementarla.

No implementes una interfaz solamente para cumplir el ejercicio.

Justifica la responsabilidad.

---

## Nivel 10 — Strategy

Crea dos estrategias para ordenar materiales:

```text
OrdenPorNombre
OrdenPorId
```

Define un contrato común y permite cambiar la estrategia.

---

# Desafío integrador

Construye un pequeño sistema utilizando:

- paquete `model`;
- paquete `data`;
- paquete `main`;
- al menos una clase base;
- al menos dos clases hijas;
- composición;
- encapsulamiento;
- sobrecarga;
- sobrescritura;
- polimorfismo;
- una clase abstracta;
- una interfaz;
- una clase que implemente esa interfaz.

Luego explica:

> dónde aparece cada concepto y qué problema resuelve.
