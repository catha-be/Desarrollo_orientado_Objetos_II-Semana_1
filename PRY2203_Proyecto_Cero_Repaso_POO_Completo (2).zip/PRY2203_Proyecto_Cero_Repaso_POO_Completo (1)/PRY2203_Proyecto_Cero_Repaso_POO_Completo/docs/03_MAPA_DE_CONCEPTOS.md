# 03 — Mapa de conceptos POO

## Clase

Molde que define estado y comportamiento.

```java
public class Producto {
}
```

## Objeto

Instancia concreta de una clase.

```java
Producto producto = new Producto(...);
```

## Atributo

Dato que describe el estado de un objeto.

```java
private String nombre;
```

## Método

Comportamiento asociado a una clase u objeto.

```java
public void mostrar() {
}
```

## Constructor

Inicializa un objeto.

```java
public Producto(String nombre) {
    this.nombre = nombre;
}
```

## `this`

Referencia al objeto actual.

```java
this.nombre = nombre;
```

## Encapsulamiento

Protección del estado interno.

```java
private String nombre;
```

Acceso controlado:

```java
getNombre()
setNombre(...)
```

## `toString()`

Representación textual del objeto.

```java
@Override
public String toString() {
    ...
}
```

## Composición

Relación:

```text
TIENE UN
```

Ejemplo:

```java
private Direccion direccion;
```

## Herencia

Relación:

```text
ES UN
```

Ejemplo:

```java
public class Libro extends Recurso
```

## `super`

Permite acceder al constructor o comportamiento de la clase padre.

```java
super(id, titulo);
```

## Sobrecarga

Mismo método, distinta firma.

```java
buscar(String texto)
buscar(int id)
```

## Sobrescritura

Una clase hija redefine un método heredado.

```java
@Override
public void enviar() {
}
```

## Polimorfismo

Una referencia general puede representar objetos concretos diferentes.

```java
Recurso recurso = new Libro(...);
```

## Clase abstracta

Modelo incompleto que no se instancia directamente.

```java
public abstract class Recurso {
}
```

## Método abstracto

Declara una operación que las subclases deben completar.

```java
protected abstract void mostrarDetalleEspecifico();
```

## Interfaz

Contrato de comportamiento.

```java
public interface Prestable {
    void prestar();
}
```

## `implements`

Una clase se compromete con una interfaz.

```java
public class Libro implements Prestable
```

## Template Method

La clase base define el flujo general y las subclases completan ciertos pasos.

## Strategy

Un comportamiento se encapsula detrás de una interfaz y puede intercambiarse sin modificar la clase que lo utiliza.

## Idea final

```text
Herencia      = ES UN
Composición   = TIENE UN
Interfaz      = PUEDE HACER / CUMPLE UN CONTRATO
Polimorfismo  = MISMA ABSTRACCIÓN, DIFERENTES COMPORTAMIENTOS
```
