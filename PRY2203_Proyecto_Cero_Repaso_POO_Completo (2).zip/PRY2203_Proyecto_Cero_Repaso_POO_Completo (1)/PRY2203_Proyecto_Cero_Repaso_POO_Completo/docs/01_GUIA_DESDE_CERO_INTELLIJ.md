# 01 — Crear el proyecto desde cero en IntelliJ IDEA

## Objetivo

Antes de estudiar herencia o polimorfismo debemos comprender cómo nace un proyecto Java.

---

## Paso 1 — Abrir IntelliJ IDEA

Selecciona:

```text
New Project
```

## Paso 2 — Configurar el proyecto

Usa:

```text
Language: Java
JDK: Java 21
```

Nombre sugerido:

```text
PRY2203-Repaso-POO
```

No necesitas Spring, JavaFX ni una base de datos para este proyecto.

---

## Paso 3 — Crear la carpeta `src`

IntelliJ normalmente crea el origen del proyecto.

Dentro de `src` trabajaremos con paquetes.

Paquete base sugerido:

```text
cl.duoc.pry2203.repaso
```

### ¿Qué es un paquete?

Un paquete organiza clases relacionadas y evita tener todo el código en una sola carpeta.

Ejemplo:

```text
cl.duoc.pry2203.repaso.integrador.model
```

se traduce físicamente en carpetas:

```text
cl/
└── duoc/
    └── pry2203/
        └── repaso/
            └── integrador/
                └── model/
```

---

## Paso 4 — Crear una clase

En IntelliJ:

```text
clic derecho sobre el paquete
New
Java Class
```

Nombre:

```text
Producto
```

Una clase comienza así:

```java
public class Producto {

}
```

Todavía no existe ningún objeto.

Solo tenemos el molde.

---

## Paso 5 — Crear `Main`

```java
public class Main {

    public static void main(String[] args) {

    }
}
```

El método:

```java
public static void main(String[] args)
```

es el punto de entrada habitual de una aplicación Java sencilla.

---

## Paso 6 — Compilar y ejecutar

Presiona el botón de ejecución junto al método `main`.

Si no aparecen errores de compilación, Java puede ejecutar el programa.

Pero recuerda:

> compilar correctamente no demuestra por sí solo que la lógica esté bien.
