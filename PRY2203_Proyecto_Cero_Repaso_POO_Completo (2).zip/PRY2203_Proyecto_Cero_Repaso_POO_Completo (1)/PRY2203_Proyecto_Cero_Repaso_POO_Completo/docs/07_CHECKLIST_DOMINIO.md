# 07 — Checklist de dominio

Marca una opción:

```text
[ ] Puedo explicar qué es una clase.
[ ] Puedo explicar qué es un objeto.
[ ] Puedo distinguir clase de objeto.
[ ] Comprendo atributos y métodos.
[ ] Comprendo el constructor.
[ ] Sé para qué sirve this.
[ ] Comprendo private y encapsulamiento.
[ ] Sé utilizar getters y setters.
[ ] Comprendo toString().
[ ] Distingo composición de herencia.
[ ] Sé utilizar extends.
[ ] Comprendo super(...).
[ ] Distingo sobrecarga de sobrescritura.
[ ] Comprendo @Override.
[ ] Comprendo polimorfismo.
[ ] Puedo explicar referencia vs. objeto real.
[ ] Comprendo una clase abstracta.
[ ] Comprendo un método abstracto.
[ ] Comprendo una interfaz.
[ ] Sé qué significa implements.
[ ] Sé que una clase puede implementar varias interfaces.
[ ] Comprendo el propósito de Template Method.
[ ] Comprendo el propósito de Strategy.
[ ] Puedo recorrer una colección polimórfica.
[ ] Comprendo la responsabilidad de model.
[ ] Comprendo la responsabilidad de data.
[ ] Comprendo la responsabilidad de service.
[ ] Comprendo la responsabilidad de main.
[ ] Sé hacer git init.
[ ] Sé hacer git status.
[ ] Sé hacer git add.
[ ] Sé crear un commit.
[ ] Distingo commit de push.
[ ] Sé conectar origin.
[ ] Sé hacer el primer push.
[ ] Sé comprobar el resultado en GitHub.
```

No marques una casilla porque "lo viste".

Márcala cuando seas capaz de explicarla y demostrarla.
