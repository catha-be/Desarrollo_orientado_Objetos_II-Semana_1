# 04 — Ruta de ejecución

Ejecuta los ejemplos en este orden:

```text
e01_clase_objeto/MainClaseObjeto
e02_encapsulamiento/MainEncapsulamiento
e03_composicion/MainComposicion
e04_herencia/MainHerencia
e05_sobrecarga/MainSobrecarga
e06_sobrescritura/MainSobrescritura
e07_polimorfismo/MainPolimorfismo
e08_abstracta_template/MainAbstracta
e09_interfaces/MainInterfaces
e10_strategy/MainStrategy
integrador/main/Main
```

## Método de estudio recomendado

Para cada ejemplo:

1. Ejecuta sin modificar.
2. Predice la salida.
3. Lee la salida.
4. Vuelve al código.
5. Identifica la línea que causó cada resultado.
6. Cambia un dato.
7. Vuelve a ejecutar.
8. Comete un error intencional.
9. Lee el error del compilador.
10. Corrige.
11. Explica en voz alta qué aprendiste.

Ese último paso importa mucho:

> Si puedes explicarlo con tus palabras, estás comenzando a dominarlo.
