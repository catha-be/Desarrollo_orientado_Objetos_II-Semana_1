package cl.duoc.pry2203.repaso.integrador.interfaces;

/**
 * Segunda interfaz para demostrar que una clase puede
 * implementar más de un contrato.
 */
public interface Descargable {

    void descargar();
}
