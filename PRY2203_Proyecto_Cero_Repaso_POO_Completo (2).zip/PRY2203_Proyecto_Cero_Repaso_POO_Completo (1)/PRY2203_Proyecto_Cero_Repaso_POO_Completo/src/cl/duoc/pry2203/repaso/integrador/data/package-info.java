/**
 * Administración de datos en memoria.
 */
package cl.duoc.pry2203.repaso.integrador.data;
