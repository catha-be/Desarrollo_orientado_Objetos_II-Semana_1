package cl.duoc.pry2203.repaso.integrador.model;

import cl.duoc.pry2203.repaso.integrador.interfaces.Descargable;
import cl.duoc.pry2203.repaso.integrador.interfaces.Prestable;

/**
 * Una clase puede:
 *
 * EXTENDER una clase:
 *     extends Recurso
 *
 * e IMPLEMENTAR múltiples interfaces:
 *     implements Prestable, Descargable
 */
public class RecursoDigital extends Recurso implements Prestable, Descargable {

    private String formato;

    public RecursoDigital(int id, String titulo, String formato) {
        super(id, titulo);
        this.formato = formato;
    }

    @Override
    protected void mostrarDetalleEspecifico() {
        System.out.println("Tipo: Recurso digital");
        System.out.println("Formato: " + formato);
    }

    @Override
    public void prestar() {
        if (isDisponible()) {
            setDisponible(false);
            System.out.println("Acceso digital habilitado para: " + getTitulo());
        } else {
            System.out.println("El recurso digital ya se encuentra asignado.");
        }
    }

    @Override
    public void devolver() {
        setDisponible(true);
        System.out.println("Acceso digital liberado: " + getTitulo());
    }

    @Override
    public void descargar() {
        System.out.println("Descargando " + getTitulo() + "." + formato.toLowerCase());
    }
}
