package cl.duoc.pry2203.repaso.integrador.main;

import cl.duoc.pry2203.repaso.integrador.data.CatalogoData;
import cl.duoc.pry2203.repaso.integrador.interfaces.Descargable;
import cl.duoc.pry2203.repaso.integrador.model.Prestamo;
import cl.duoc.pry2203.repaso.integrador.model.Recurso;
import cl.duoc.pry2203.repaso.integrador.model.Usuario;
import cl.duoc.pry2203.repaso.integrador.service.ServicioPrestamos;
import cl.duoc.pry2203.repaso.integrador.strategy.PoliticaEstandar;
import cl.duoc.pry2203.repaso.integrador.strategy.PoliticaPreferente;

/**
 * ================================================================
 * MAIN INTEGRADOR
 * ================================================================
 *
 * Este Main conecta los conceptos aprendidos:
 *
 * - objetos;
 * - encapsulamiento;
 * - herencia;
 * - composición;
 * - clases abstractas;
 * - sobrecarga;
 * - sobrescritura;
 * - polimorfismo;
 * - interfaces;
 * - implements;
 * - múltiples interfaces;
 * - ArrayList;
 * - Template Method;
 * - Strategy;
 * - separación model/data/service/main.
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("\n=== 1. CREAR EL CATÁLOGO ===\n");

        CatalogoData catalogo = new CatalogoData();
        catalogo.cargarDatosIniciales();

        System.out.println("\n=== 2. POLIMORFISMO + TEMPLATE METHOD ===\n");

        /*
         * La colección almacena Recurso.
         *
         * Sin embargo, los objetos reales son Libro o RecursoDigital.
         *
         * La llamada es la misma:
         *     recurso.mostrarFichaCompleta()
         *
         * Dentro del Template Method, Java termina llamando al
         * detalle específico de cada subclase.
         */
        for (Recurso recurso : catalogo.obtenerTodos()) {
            recurso.mostrarFichaCompleta();
        }

        System.out.println("\n=== 3. SOBRECARGA ===\n");

        Recurso primerRecurso = catalogo.obtenerTodos().get(0);

        primerRecurso.buscarCoincidencia("Programación");
        primerRecurso.buscarCoincidencia(1);

        System.out.println("\n=== 4. STRATEGY ===\n");

        Usuario usuario = new Usuario(
                100,
                "Estudiante de ejemplo",
                true
        );

        ServicioPrestamos servicio =
                new ServicioPrestamos(new PoliticaEstandar());

        Prestamo prestamo1 =
                servicio.crearPrestamo(
                        usuario,
                        catalogo.buscarPorId(1)
                );

        System.out.println("Resultado: " + prestamo1);

        /*
         * Cambiamos la estrategia SIN modificar ServicioPrestamos.
         */
        servicio.setPoliticaPrestamo(new PoliticaPreferente());

        Prestamo prestamo2 =
                servicio.crearPrestamo(
                        usuario,
                        catalogo.buscarPorId(2)
                );

        System.out.println("Resultado: " + prestamo2);

        System.out.println("\n=== 5. INTERFAZ ADICIONAL ===\n");

        Recurso segundoRecurso = catalogo.buscarPorId(2);

        /*
         * RecursoDigital implementa Descargable.
         *
         * Usamos el contrato en vez de depender directamente
         * de la clase concreta.
         */
        if (segundoRecurso instanceof Descargable descargable) {
            descargable.descargar();
        }

        System.out.println("\n=== 6. PREGUNTAS PARA EXPLICAR ===\n");

        System.out.println("""
                1. ¿Por qué Recurso es abstracta?
                2. ¿Qué heredan Libro y RecursoDigital?
                3. ¿Qué métodos están sobrescritos?
                4. ¿Dónde existe sobrecarga?
                5. ¿Dónde observamos polimorfismo?
                6. ¿Qué diferencia existe entre extends e implements?
                7. ¿Dónde observamos composición?
                8. ¿Qué contrato define Prestable?
                9. ¿Por qué RecursoDigital puede implementar dos interfaces?
                10. ¿Cómo funciona el Template Method?
                11. ¿Cómo cambia Strategy sin modificar el servicio?
                12. ¿Qué responsabilidad tiene cada paquete?
                """);
    }
}
