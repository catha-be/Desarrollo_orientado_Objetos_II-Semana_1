package cl.duoc.pry2203.repaso.integrador.interfaces;

/**
 * CONTRATO:
 * cualquier clase que implemente Prestable debe indicar
 * cómo se presta y cómo se devuelve.
 */
public interface Prestable {

    void prestar();

    void devolver();
}
