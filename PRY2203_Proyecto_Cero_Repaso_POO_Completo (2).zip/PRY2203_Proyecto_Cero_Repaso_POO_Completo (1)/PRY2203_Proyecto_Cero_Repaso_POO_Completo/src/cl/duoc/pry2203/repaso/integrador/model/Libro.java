package cl.duoc.pry2203.repaso.integrador.model;

import cl.duoc.pry2203.repaso.integrador.interfaces.Prestable;

/**
 * HERENCIA + IMPLEMENTACIÓN DE INTERFAZ.
 *
 * Libro:
 * - ES UN Recurso        -> extends
 * - PUEDE SER prestado   -> implements Prestable
 */
public class Libro extends Recurso implements Prestable {

    private String autor;

    public Libro(int id, String titulo, String autor) {
        super(id, titulo);
        this.autor = autor;
    }

    public String getAutor() {
        return autor;
    }

    @Override
    protected void mostrarDetalleEspecifico() {
        System.out.println("Tipo: Libro");
        System.out.println("Autor: " + autor);
    }

    @Override
    public void prestar() {
        if (isDisponible()) {
            setDisponible(false);
            System.out.println("Libro prestado: " + getTitulo());
        } else {
            System.out.println("El libro ya se encuentra prestado.");
        }
    }

    @Override
    public void devolver() {
        setDisponible(true);
        System.out.println("Libro devuelto: " + getTitulo());
    }

    @Override
    public String toString() {
        return "Libro{" +
                "id=" + getId() +
                ", titulo='" + getTitulo() + '\'' +
                ", autor='" + autor + '\'' +
                ", disponible=" + isDisponible() +
                '}';
    }
}
