package cl.duoc.pry2203.repaso.integrador.model;

/**
 * ================================================================
 * PROYECTO INTEGRADOR - CLASE ABSTRACTA
 * ================================================================
 *
 * Recurso representa aquello que comparten distintos recursos.
 *
 * Es ABSTRACTA porque queremos modelar una idea general.
 * No queremos crear un "Recurso genérico" directamente.
 *
 * Sí queremos crear:
 * - Libro;
 * - RecursoDigital.
 */
public abstract class Recurso {

    // ENCAPSULAMIENTO
    private int id;
    private String titulo;
    private boolean disponible;

    public Recurso(int id, String titulo) {
        this.id = id;
        this.titulo = titulo;
        this.disponible = true;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setTitulo(String titulo) {
        if (titulo != null && !titulo.isBlank()) {
            this.titulo = titulo;
        }
    }

    protected void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    /**
     * MÉTODO CONCRETO:
     * ya tiene implementación y puede ser reutilizado por las hijas.
     */
    public void mostrarDatosBasicos() {
        System.out.println("ID: " + id);
        System.out.println("Título: " + titulo);
        System.out.println("Disponible: " + disponible);
    }

    /**
     * MÉTODO ABSTRACTO:
     * cada subclase debe implementar su detalle específico.
     */
    protected abstract void mostrarDetalleEspecifico();

    /**
     * TEMPLATE METHOD:
     * define un flujo común.
     *
     * 1. muestra encabezado;
     * 2. muestra datos comunes;
     * 3. delega el detalle específico a la subclase;
     * 4. cierra la ficha.
     */
    public final void mostrarFichaCompleta() {
        System.out.println("================================");
        mostrarDatosBasicos();
        mostrarDetalleEspecifico();
        System.out.println("================================");
    }

    /**
     * SOBRECARGA:
     * mismo nombre con diferente firma.
     */
    public void buscarCoincidencia(String texto) {
        System.out.println("Buscando por texto: " + texto);
    }

    public void buscarCoincidencia(int id) {
        System.out.println("Buscando por ID: " + id);
    }

    @Override
    public String toString() {
        return "Recurso{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", disponible=" + disponible +
                '}';
    }
}
