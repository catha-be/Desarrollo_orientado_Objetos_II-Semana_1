/**
 * Entidades y clases de dominio del proyecto integrador.
 */
package cl.duoc.pry2203.repaso.integrador.model;
