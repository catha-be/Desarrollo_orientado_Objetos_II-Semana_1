package cl.duoc.pry2203.repaso.ejemplos.e10_strategy;

/**
 * ================================================================
 * EJEMPLO 10 - STRATEGY
 * ================================================================
 *
 * La calculadora NO conoce todos los algoritmos.
 *
 * Recibe un objeto que cumple el contrato Operacion.
 *
 * Así desacoplamos:
 * - QUIÉN usa el algoritmo;
 * - del algoritmo concreto.
 */
public class CalculadoraFlexible {

    private Operacion operacion;

    public CalculadoraFlexible(Operacion operacion) {
        this.operacion = operacion;
    }

    public void setOperacion(Operacion operacion) {
        this.operacion = operacion;
    }

    public int calcular(int a, int b) {
        return operacion.ejecutar(a, b);
    }
}
