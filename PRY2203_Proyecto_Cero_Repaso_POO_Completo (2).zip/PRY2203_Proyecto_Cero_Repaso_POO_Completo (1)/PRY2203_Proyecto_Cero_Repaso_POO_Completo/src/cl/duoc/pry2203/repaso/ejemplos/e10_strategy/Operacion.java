package cl.duoc.pry2203.repaso.ejemplos.e10_strategy;

/**
 * Contrato de una estrategia.
 */
public interface Operacion {

    int ejecutar(int a, int b);
}
