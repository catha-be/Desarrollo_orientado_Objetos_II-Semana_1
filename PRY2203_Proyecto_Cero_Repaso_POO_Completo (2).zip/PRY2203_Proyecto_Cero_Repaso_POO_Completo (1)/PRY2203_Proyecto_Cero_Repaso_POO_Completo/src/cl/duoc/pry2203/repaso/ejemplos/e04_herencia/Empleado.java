package cl.duoc.pry2203.repaso.ejemplos.e04_herencia;

/**
 * ================================================================
 * EJEMPLO 04 - HERENCIA
 * ================================================================
 *
 * Empleado será la CLASE PADRE.
 *
 * Los datos comunes se escriben una sola vez aquí.
 */
public class Empleado {

    private String nombre;

    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void trabajar() {
        System.out.println(nombre + " realiza una tarea general.");
    }
}
