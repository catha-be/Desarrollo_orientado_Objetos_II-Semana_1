package cl.duoc.pry2203.repaso.ejemplos.e03_composicion;

public class MainComposicion {

    public static void main(String[] args) {

        Direccion direccion = new Direccion("Av. Central 123", "Santiago");

        // La Persona se construye UTILIZANDO otro objeto.
        Persona persona = new Persona("Diego", direccion);

        persona.mostrarDatos();
    }
}
