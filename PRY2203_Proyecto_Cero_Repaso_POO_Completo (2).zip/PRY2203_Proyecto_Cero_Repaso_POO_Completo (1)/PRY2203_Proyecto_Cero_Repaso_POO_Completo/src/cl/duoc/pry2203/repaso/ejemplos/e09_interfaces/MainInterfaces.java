package cl.duoc.pry2203.repaso.ejemplos.e09_interfaces;

public class MainInterfaces {

    public static void main(String[] args) {

        Reporte reporte = new Reporte("Resumen mensual");

        reporte.imprimir();
        reporte.exportar("PDF");
    }
}
