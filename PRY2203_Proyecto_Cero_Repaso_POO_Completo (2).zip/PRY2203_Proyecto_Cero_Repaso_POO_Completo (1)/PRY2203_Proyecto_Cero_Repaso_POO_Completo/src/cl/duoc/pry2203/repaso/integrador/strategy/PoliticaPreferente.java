package cl.duoc.pry2203.repaso.integrador.strategy;

import cl.duoc.pry2203.repaso.integrador.model.Recurso;
import cl.duoc.pry2203.repaso.integrador.model.Usuario;

public class PoliticaPreferente implements PoliticaPrestamo {

    @Override
    public int calcularDias(Usuario usuario, Recurso recurso) {
        return usuario.isPreferente() ? 14 : 7;
    }
}
