package cl.duoc.pry2203.repaso.ejemplos.e04_herencia;

public class MainHerencia {

    public static void main(String[] args) {

        Desarrollador desarrollador = new Desarrollador("Sofía", "Java");

        // Método heredado desde Empleado.
        desarrollador.trabajar();

        // Método propio de Desarrollador.
        desarrollador.programar();
    }
}
