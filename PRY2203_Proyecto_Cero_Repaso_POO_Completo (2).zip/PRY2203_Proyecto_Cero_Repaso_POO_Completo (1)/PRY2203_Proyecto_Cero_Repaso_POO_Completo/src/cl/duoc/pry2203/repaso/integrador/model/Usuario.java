package cl.duoc.pry2203.repaso.integrador.model;

/**
 * Clase sencilla para repasar:
 * - encapsulamiento;
 * - constructor;
 * - getters/setters;
 * - toString().
 */
public class Usuario {

    private int id;
    private String nombre;
    private boolean preferente;

    public Usuario(int id, String nombre, boolean preferente) {
        this.id = id;
        this.nombre = nombre;
        this.preferente = preferente;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean isPreferente() {
        return preferente;
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.isBlank()) {
            this.nombre = nombre;
        }
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", preferente=" + preferente +
                '}';
    }
}
