package cl.duoc.pry2203.repaso.ejemplos.e02_encapsulamiento;

public class MainEncapsulamiento {

    public static void main(String[] args) {

        CuentaUsuario usuario = new CuentaUsuario("Valentina", 21);

        // GETTER: lee el dato privado.
        System.out.println("Nombre: " + usuario.getNombre());

        // SETTER: modifica el dato de forma controlada.
        usuario.setEdad(22);

        // Intentamos un valor inválido.
        usuario.setEdad(-10);

        // Java llama automáticamente a toString().
        System.out.println(usuario);
    }
}
