package cl.duoc.pry2203.repaso.ejemplos.e06_sobrescritura;

/**
 * Clase padre con comportamiento general.
 */
public class Notificacion {

    public void enviar() {
        System.out.println("Enviando una notificación genérica.");
    }
}
