package cl.duoc.pry2203.repaso.ejemplos.e10_strategy;

public class Multiplicacion implements Operacion {

    @Override
    public int ejecutar(int a, int b) {
        return a * b;
    }
}
