package cl.duoc.pry2203.repaso.ejemplos.e06_sobrescritura;

public class MainSobrescritura {

    public static void main(String[] args) {

        NotificacionEmail email = new NotificacionEmail();
        NotificacionApp app = new NotificacionApp();

        email.enviar();
        app.enviar();
    }
}
