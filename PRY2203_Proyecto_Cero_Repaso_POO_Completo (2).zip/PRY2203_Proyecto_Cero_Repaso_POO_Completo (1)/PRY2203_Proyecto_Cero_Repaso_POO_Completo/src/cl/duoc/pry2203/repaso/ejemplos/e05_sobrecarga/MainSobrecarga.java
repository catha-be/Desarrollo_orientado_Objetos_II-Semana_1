package cl.duoc.pry2203.repaso.ejemplos.e05_sobrecarga;

public class MainSobrecarga {

    public static void main(String[] args) {

        Calculadora calculadora = new Calculadora();

        System.out.println(calculadora.sumar(2, 3));
        System.out.println(calculadora.sumar(2, 3, 4));
        System.out.println(calculadora.sumar(2.5, 3.5));
    }
}
