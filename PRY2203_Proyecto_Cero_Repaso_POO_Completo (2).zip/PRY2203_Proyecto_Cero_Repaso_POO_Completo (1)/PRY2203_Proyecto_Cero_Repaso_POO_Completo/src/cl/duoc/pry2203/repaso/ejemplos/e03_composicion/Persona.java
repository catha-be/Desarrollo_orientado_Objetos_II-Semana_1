package cl.duoc.pry2203.repaso.ejemplos.e03_composicion;

/**
 * ================================================================
 * EJEMPLO 03 - COMPOSICIÓN
 * ================================================================
 *
 * COMPOSICIÓN representa una relación "TIENE UN".
 *
 * Una Persona TIENE UNA Direccion.
 *
 * Esto es diferente de herencia.
 *
 * Herencia:
 *     "Un Libro ES UN Recurso".
 *
 * Composición:
 *     "Una Persona TIENE UNA Direccion".
 */
public class Persona {

    private String nombre;

    // Este atributo es un OBJETO de otra clase.
    private Direccion direccion;

    public Persona(String nombre, Direccion direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public void mostrarDatos() {
        System.out.println(nombre + " vive en " + direccion);
    }
}
