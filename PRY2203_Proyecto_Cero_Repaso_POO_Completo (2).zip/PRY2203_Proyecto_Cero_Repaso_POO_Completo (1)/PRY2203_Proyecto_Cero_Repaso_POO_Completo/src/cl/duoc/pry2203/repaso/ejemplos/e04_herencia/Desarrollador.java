package cl.duoc.pry2203.repaso.ejemplos.e04_herencia;

/**
 * "extends Empleado" significa:
 *
 * Desarrollador ES UN Empleado.
 *
 * La clase hija hereda miembros accesibles de la clase padre.
 */
public class Desarrollador extends Empleado {

    private String lenguajePrincipal;

    public Desarrollador(String nombre, String lenguajePrincipal) {

        // super(...) llama al constructor de la clase padre.
        super(nombre);

        this.lenguajePrincipal = lenguajePrincipal;
    }

    public void programar() {
        System.out.println(getNombre() + " programa en " + lenguajePrincipal + ".");
    }
}
