/**
 * Contratos desacoplados mediante interfaces.
 */
package cl.duoc.pry2203.repaso.integrador.interfaces;
