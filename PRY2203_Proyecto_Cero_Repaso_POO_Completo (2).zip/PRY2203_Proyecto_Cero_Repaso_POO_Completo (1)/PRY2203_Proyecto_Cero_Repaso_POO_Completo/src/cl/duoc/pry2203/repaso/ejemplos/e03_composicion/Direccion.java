package cl.duoc.pry2203.repaso.ejemplos.e03_composicion;

/**
 * Parte de una composición.
 *
 * Una Dirección puede ser utilizada por otra clase.
 */
public class Direccion {

    private String calle;
    private String ciudad;

    public Direccion(String calle, String ciudad) {
        this.calle = calle;
        this.ciudad = ciudad;
    }

    @Override
    public String toString() {
        return calle + ", " + ciudad;
    }
}
