package cl.duoc.pry2203.repaso.ejemplos.e09_interfaces;

/**
 * IMPLEMENTACIÓN DE INTERFACES.
 *
 * "implements" significa que la clase se compromete
 * a implementar los métodos definidos por la interfaz.
 *
 * Java permite implementar múltiples interfaces.
 */
public class Reporte implements Imprimible, Exportable {

    private String titulo;

    public Reporte(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public void imprimir() {
        System.out.println("Imprimiendo reporte: " + titulo);
    }

    @Override
    public void exportar(String formato) {
        System.out.println("Exportando " + titulo + " como " + formato);
    }
}
