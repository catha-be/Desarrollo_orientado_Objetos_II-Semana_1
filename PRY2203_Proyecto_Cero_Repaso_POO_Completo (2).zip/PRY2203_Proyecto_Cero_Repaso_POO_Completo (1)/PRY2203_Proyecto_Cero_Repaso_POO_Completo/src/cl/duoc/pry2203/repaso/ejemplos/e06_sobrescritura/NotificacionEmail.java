package cl.duoc.pry2203.repaso.ejemplos.e06_sobrescritura;

/**
 * ================================================================
 * EJEMPLO 06 - SOBRESCRITURA
 * ================================================================
 *
 * SOBRESCRITURA:
 * una clase hija redefine un método heredado.
 *
 * MISMO nombre.
 * MISMOS parámetros.
 * MISMO tipo de retorno compatible.
 * NUEVO comportamiento.
 */
public class NotificacionEmail extends Notificacion {

    @Override
    public void enviar() {
        System.out.println("Enviando notificación mediante correo electrónico.");
    }
}
