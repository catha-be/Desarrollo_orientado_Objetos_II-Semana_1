package cl.duoc.pry2203.repaso.integrador.data;

import cl.duoc.pry2203.repaso.integrador.model.Libro;
import cl.duoc.pry2203.repaso.integrador.model.Recurso;
import cl.duoc.pry2203.repaso.integrador.model.RecursoDigital;

import java.util.ArrayList;
import java.util.List;

/**
 * ================================================================
 * PAQUETE data
 * ================================================================
 *
 * Esta clase administra recursos en memoria.
 *
 * Utilizamos ArrayList como repaso de colecciones.
 *
 * En semanas posteriores el origen de los datos podría cambiar
 * por una base de datos. La idea de separar responsabilidades
 * desde ahora facilita esa evolución.
 */
public class CatalogoData {

    private List<Recurso> recursos;

    public CatalogoData() {
        recursos = new ArrayList<>();
    }

    public void cargarDatosIniciales() {
        recursos.add(new Libro(
                1,
                "Programación Orientada a Objetos",
                "Autor de ejemplo"
        ));

        recursos.add(new RecursoDigital(
                2,
                "Guía de Arquitectura",
                "PDF"
        ));
    }

    public void agregar(Recurso recurso) {
        recursos.add(recurso);
    }

    public List<Recurso> obtenerTodos() {
        return recursos;
    }

    public Recurso buscarPorId(int id) {
        for (Recurso recurso : recursos) {
            if (recurso.getId() == id) {
                return recurso;
            }
        }

        return null;
    }
}
