package cl.duoc.pry2203.repaso.ejemplos.e06_sobrescritura;

public class NotificacionApp extends Notificacion {

    @Override
    public void enviar() {
        System.out.println("Enviando notificación dentro de la aplicación.");
    }
}
