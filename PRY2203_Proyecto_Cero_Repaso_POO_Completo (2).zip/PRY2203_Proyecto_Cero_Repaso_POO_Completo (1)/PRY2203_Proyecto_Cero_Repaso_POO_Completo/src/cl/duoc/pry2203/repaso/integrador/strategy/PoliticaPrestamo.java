package cl.duoc.pry2203.repaso.integrador.strategy;

import cl.duoc.pry2203.repaso.integrador.model.Recurso;
import cl.duoc.pry2203.repaso.integrador.model.Usuario;

/**
 * STRATEGY:
 * este contrato representa una forma de calcular
 * la cantidad de días permitidos para un préstamo.
 */
public interface PoliticaPrestamo {

    int calcularDias(Usuario usuario, Recurso recurso);
}
