package cl.duoc.pry2203.repaso.ejemplos.e09_interfaces;

/**
 * ================================================================
 * EJEMPLO 09 - INTERFAZ
 * ================================================================
 *
 * Una interfaz define un CONTRATO.
 *
 * Indica QUÉ operación debe existir,
 * pero no obliga a que todas las clases la resuelvan igual.
 */
public interface Imprimible {

    void imprimir();
}
