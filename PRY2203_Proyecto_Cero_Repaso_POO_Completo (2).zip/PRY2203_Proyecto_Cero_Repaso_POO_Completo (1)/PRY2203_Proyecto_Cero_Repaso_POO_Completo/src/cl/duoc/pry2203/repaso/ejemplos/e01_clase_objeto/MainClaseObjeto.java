package cl.duoc.pry2203.repaso.ejemplos.e01_clase_objeto;

/**
 * Ejecuta este Main primero.
 *
 * Aquí observamos la diferencia entre:
 *
 * CLASE  -> Producto
 * OBJETO -> producto1
 */
public class MainClaseObjeto {

    public static void main(String[] args) {

        // "Producto" es el tipo.
        // "producto1" es una variable de referencia.
        // "new Producto(...)" crea el objeto.
        Producto producto1 = new Producto("Teclado", 25000);

        Producto producto2 = new Producto("Mouse", 15000);

        // Cada objeto mantiene su propio estado.
        producto1.mostrarInformacion();
        producto2.mostrarInformacion();
    }
}
