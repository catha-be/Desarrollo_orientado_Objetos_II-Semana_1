package cl.duoc.pry2203.repaso.ejemplos.e05_sobrecarga;

/**
 * ================================================================
 * EJEMPLO 05 - SOBRECARGA
 * ================================================================
 *
 * SOBRECARGA:
 * mismo nombre de método + distinta lista de parámetros.
 *
 * Java selecciona el método según los argumentos enviados.
 */
public class Calculadora {

    public int sumar(int a, int b) {
        return a + b;
    }

    public int sumar(int a, int b, int c) {
        return a + b + c;
    }

    public double sumar(double a, double b) {
        return a + b;
    }

    // IMPORTANTE:
    // cambiar solamente el tipo de retorno NO crea una sobrecarga válida.
}
