package cl.duoc.pry2203.repaso.ejemplos.e08_abstracta_template;

public class MainAbstracta {

    public static void main(String[] args) {

        // No podemos hacer:
        // Documento documento = new Documento("archivo");
        //
        // porque Documento es abstracta.

        Documento documento = new DocumentoTexto("informe.txt");

        documento.procesar();
    }
}
