package cl.duoc.pry2203.repaso.integrador.model;

/**
 * ================================================================
 * COMPOSICIÓN EN EL PROYECTO INTEGRADOR
 * ================================================================
 *
 * Un Prestamo TIENE UN Usuario.
 * Un Prestamo TIENE UN Recurso.
 *
 * Esto es una relación "has-a" / "tiene un".
 */
public class Prestamo {

    private Usuario usuario;
    private Recurso recurso;
    private int dias;

    public Prestamo(Usuario usuario, Recurso recurso, int dias) {
        this.usuario = usuario;
        this.recurso = recurso;
        this.dias = dias;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Recurso getRecurso() {
        return recurso;
    }

    public int getDias() {
        return dias;
    }

    @Override
    public String toString() {
        return "Prestamo{" +
                "usuario=" + usuario.getNombre() +
                ", recurso=" + recurso.getTitulo() +
                ", dias=" + dias +
                '}';
    }
}
