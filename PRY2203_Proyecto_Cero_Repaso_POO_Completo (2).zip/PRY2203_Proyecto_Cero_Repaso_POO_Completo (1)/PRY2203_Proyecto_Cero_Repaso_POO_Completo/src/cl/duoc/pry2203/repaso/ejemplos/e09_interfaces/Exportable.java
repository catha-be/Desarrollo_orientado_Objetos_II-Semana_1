package cl.duoc.pry2203.repaso.ejemplos.e09_interfaces;

public interface Exportable {

    void exportar(String formato);
}
