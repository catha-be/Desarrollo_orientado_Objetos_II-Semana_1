package cl.duoc.pry2203.repaso.ejemplos.e01_clase_objeto;

/**
 * ================================================================
 * EJEMPLO 01 - CLASE, OBJETO, ATRIBUTOS, MÉTODOS Y CONSTRUCTOR
 * ================================================================
 *
 * Una CLASE es un molde.
 * Describe qué datos y qué comportamientos tendrán sus objetos.
 *
 * Producto es la clase.
 * Cuando hacemos:
 *
 *     new Producto("Teclado", 25000)
 *
 * estamos creando un OBJETO a partir de ese molde.
 */
public class Producto {

    // ATRIBUTOS:
    // representan el estado o los datos del objeto.
    private String nombre;
    private int precio;

    /**
     * CONSTRUCTOR:
     * se ejecuta cuando creamos un nuevo objeto con "new".
     *
     * this.nombre -> atributo del objeto actual.
     * nombre      -> parámetro recibido.
     */
    public Producto(String nombre, int precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    /**
     * MÉTODO:
     * representa un comportamiento que puede realizar el objeto.
     */
    public void mostrarInformacion() {
        System.out.println("Producto: " + nombre + " | Precio: $" + precio);
    }

    public String getNombre() {
        return nombre;
    }

    public int getPrecio() {
        return precio;
    }
}
