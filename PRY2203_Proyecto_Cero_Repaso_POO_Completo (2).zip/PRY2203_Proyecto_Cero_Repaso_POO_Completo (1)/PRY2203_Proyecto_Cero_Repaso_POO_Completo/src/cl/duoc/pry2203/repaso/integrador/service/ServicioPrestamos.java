package cl.duoc.pry2203.repaso.integrador.service;

import cl.duoc.pry2203.repaso.integrador.interfaces.Prestable;
import cl.duoc.pry2203.repaso.integrador.model.Prestamo;
import cl.duoc.pry2203.repaso.integrador.model.Recurso;
import cl.duoc.pry2203.repaso.integrador.model.Usuario;
import cl.duoc.pry2203.repaso.integrador.strategy.PoliticaPrestamo;

/**
 * ================================================================
 * SERVICIO + COMPOSICIÓN + STRATEGY + SOBRECARGA
 * ================================================================
 *
 * ServicioPrestamos TIENE UNA PoliticaPrestamo.
 *
 * El servicio no necesita saber cómo se calcula cada política.
 * Solo conoce el contrato PoliticaPrestamo.
 *
 * Eso disminuye el acoplamiento.
 */
public class ServicioPrestamos {

    private PoliticaPrestamo politicaPrestamo;

    public ServicioPrestamos(PoliticaPrestamo politicaPrestamo) {
        this.politicaPrestamo = politicaPrestamo;
    }

    public void setPoliticaPrestamo(PoliticaPrestamo politicaPrestamo) {
        this.politicaPrestamo = politicaPrestamo;
    }

    /**
     * SOBRECARGA 1:
     * los días se calculan utilizando la estrategia actual.
     */
    public Prestamo crearPrestamo(Usuario usuario, Recurso recurso) {

        int dias = politicaPrestamo.calcularDias(usuario, recurso);

        return crearPrestamo(usuario, recurso, dias);
    }

    /**
     * SOBRECARGA 2:
     * permite indicar explícitamente la cantidad de días.
     *
     * Mismo nombre:
     * crearPrestamo
     *
     * Diferentes parámetros.
     */
    public Prestamo crearPrestamo(
            Usuario usuario,
            Recurso recurso,
            int dias
    ) {

        // ¿Por qué usamos instanceof?
        // Porque Recurso es una clase general y necesitamos comprobar
        // si el objeto concreto también cumple el contrato Prestable.
        if (recurso instanceof Prestable prestable) {

            prestable.prestar();

            return new Prestamo(usuario, recurso, dias);
        }

        System.out.println("El recurso no admite préstamo.");
        return null;
    }
}
