package cl.duoc.pry2203.repaso.ejemplos.e02_encapsulamiento;

/**
 * ================================================================
 * EJEMPLO 02 - ENCAPSULAMIENTO, GETTERS, SETTERS Y toString()
 * ================================================================
 *
 * ENCAPSULAR significa proteger el estado interno del objeto.
 *
 * Por eso los atributos se declaran private.
 * Desde fuera de la clase no deberíamos modificarlos directamente.
 *
 * Utilizamos getters para LEER.
 * Utilizamos setters para MODIFICAR de forma controlada.
 */
public class CuentaUsuario {

    private String nombre;
    private int edad;

    public CuentaUsuario(String nombre, int edad) {
        this.nombre = nombre;
        setEdad(edad); // reutilizamos la validación del setter
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.isBlank()) {
            this.nombre = nombre;
        }
    }

    public void setEdad(int edad) {
        if (edad >= 0) {
            this.edad = edad;
        } else {
            System.out.println("Edad inválida. Se mantiene el valor anterior.");
        }
    }

    /**
     * toString() entrega una representación legible del objeto.
     *
     * @Override indica que estamos SOBRESCRIBIENDO un método
     * heredado desde Object.
     */
    @Override
    public String toString() {
        return "CuentaUsuario{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                '}';
    }
}
