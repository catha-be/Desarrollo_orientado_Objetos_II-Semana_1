package cl.duoc.pry2203.repaso.ejemplos.e08_abstracta_template;

/**
 * ================================================================
 * EJEMPLO 08 - CLASE ABSTRACTA + TEMPLATE METHOD
 * ================================================================
 *
 * Una clase abstracta NO se instancia directamente.
 *
 * Podemos tener:
 * - atributos;
 * - constructor;
 * - métodos concretos;
 * - métodos abstractos.
 *
 * TEMPLATE METHOD:
 * el método procesar() define el orden general del algoritmo.
 * Las subclases completan pasos específicos.
 */
public abstract class Documento {

    private String nombre;

    public Documento(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    /**
     * TEMPLATE METHOD.
     *
     * final evita que las subclases cambien el orden general.
     */
    public final void procesar() {
        abrir();
        validar();
        procesarContenido();
        cerrar();
    }

    private void abrir() {
        System.out.println("Abriendo " + nombre);
    }

    protected void validar() {
        System.out.println("Validación general correcta.");
    }

    /**
     * Cada tipo concreto debe definir este paso.
     */
    protected abstract void procesarContenido();

    private void cerrar() {
        System.out.println("Cerrando " + nombre);
    }
}
