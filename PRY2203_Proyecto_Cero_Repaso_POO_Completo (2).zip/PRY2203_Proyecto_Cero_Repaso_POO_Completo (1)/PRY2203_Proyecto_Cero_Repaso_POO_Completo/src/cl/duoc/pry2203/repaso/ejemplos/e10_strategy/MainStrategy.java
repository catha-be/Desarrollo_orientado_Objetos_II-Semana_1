package cl.duoc.pry2203.repaso.ejemplos.e10_strategy;

public class MainStrategy {

    public static void main(String[] args) {

        CalculadoraFlexible calculadora =
                new CalculadoraFlexible(new Suma());

        System.out.println("Suma: " + calculadora.calcular(5, 3));

        // Cambiamos la estrategia en tiempo de ejecución.
        calculadora.setOperacion(new Multiplicacion());

        System.out.println("Multiplicación: " + calculadora.calcular(5, 3));
    }
}
