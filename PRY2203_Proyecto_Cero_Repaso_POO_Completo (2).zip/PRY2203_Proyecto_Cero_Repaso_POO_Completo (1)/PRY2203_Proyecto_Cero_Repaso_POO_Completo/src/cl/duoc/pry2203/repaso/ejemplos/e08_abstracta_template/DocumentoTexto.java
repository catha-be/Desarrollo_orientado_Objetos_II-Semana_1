package cl.duoc.pry2203.repaso.ejemplos.e08_abstracta_template;

public class DocumentoTexto extends Documento {

    public DocumentoTexto(String nombre) {
        super(nombre);
    }

    @Override
    protected void procesarContenido() {
        System.out.println("Procesando contenido de texto.");
    }
}
