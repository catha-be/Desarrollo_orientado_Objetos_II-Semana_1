package cl.duoc.pry2203.repaso.ejemplos.e07_polimorfismo;

import cl.duoc.pry2203.repaso.ejemplos.e06_sobrescritura.Notificacion;
import cl.duoc.pry2203.repaso.ejemplos.e06_sobrescritura.NotificacionApp;
import cl.duoc.pry2203.repaso.ejemplos.e06_sobrescritura.NotificacionEmail;

/**
 * ================================================================
 * EJEMPLO 07 - POLIMORFISMO
 * ================================================================
 *
 * Una referencia del tipo PADRE puede apuntar a objetos de clases hijas.
 *
 * Notificacion notificacion = new NotificacionEmail();
 *
 * Tipo de referencia: Notificacion.
 * Tipo real del objeto: NotificacionEmail.
 */
public class MainPolimorfismo {

    public static void main(String[] args) {

        Notificacion[] notificaciones = {
                new NotificacionEmail(),
                new NotificacionApp()
        };

        // La misma llamada produce comportamientos diferentes.
        for (Notificacion notificacion : notificaciones) {
            notificacion.enviar();
        }
    }
}
