/**
 * Estrategias intercambiables para demostrar Strategy.
 */
package cl.duoc.pry2203.repaso.integrador.strategy;
