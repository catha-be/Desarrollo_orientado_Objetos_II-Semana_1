package cl.duoc.pry2203.semana1.duocplay.model;

/**
 * ============================================================
 * PRY2203 - SEMANA 1
 * CLASE HIJA: JuegoFamiliar
 * ============================================================
 *
 * JuegoFamiliar también ES UN JuegoMesa.
 */
public class JuegoFamiliar extends JuegoMesa {

    private int edadMinima;

    public JuegoFamiliar(
            int id,
            String nombre,
            String categoria,
            int cantidadJugadores,
            int edadMinima
    ) {
        super(id, nombre, categoria, cantidadJugadores);
        this.edadMinima = edadMinima;
    }

    public int getEdadMinima() {
        return edadMinima;
    }

    public void setEdadMinima(int edadMinima) {
        if (edadMinima >= 0) {
            this.edadMinima = edadMinima;
        }
    }

    @Override
    public void iniciarPartida() {
        System.out.println("Preparando partida familiar de "
                + getNombre()
                + ". Edad mínima recomendada: "
                + edadMinima + " años.");
    }

    public void explicarReglasRapidas() {
        System.out.println("Mostrando reglas rápidas de " + getNombre() + ".");
    }

    @Override
    public String toString() {
        return "JuegoFamiliar{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", categoria='" + getCategoria() + '\'' +
                ", cantidadJugadores=" + getCantidadJugadores() +
                ", edadMinima=" + edadMinima +
                '}';
    }
}
