/**
 * PRY2203 - Semana 1
 *
 * Paquete MODEL:
 * contiene las clases que representan los objetos del dominio DuocPlay.
 *
 * Aquí viven las entidades y su comportamiento:
 * Jugador, JuegoMesa y sus clases hijas.
 */
package cl.duoc.pry2203.semana1.duocplay.model;
