package cl.duoc.pry2203.semana1.duocplay.model;

/**
 * ============================================================
 * PRY2203 - SEMANA 1
 * CLASE HIJA: JuegoCartas
 * ============================================================
 */
public class JuegoCartas extends JuegoMesa {

    private int cantidadCartas;

    public JuegoCartas(
            int id,
            String nombre,
            String categoria,
            int cantidadJugadores,
            int cantidadCartas
    ) {
        super(id, nombre, categoria, cantidadJugadores);
        this.cantidadCartas = cantidadCartas;
    }

    public int getCantidadCartas() {
        return cantidadCartas;
    }

    public void setCantidadCartas(int cantidadCartas) {
        if (cantidadCartas > 0) {
            this.cantidadCartas = cantidadCartas;
        }
    }

    @Override
    public void iniciarPartida() {
        System.out.println("Barajando "
                + cantidadCartas
                + " cartas para iniciar "
                + getNombre() + ".");
    }

    public void barajarCartas() {
        System.out.println("Cartas de " + getNombre() + " barajadas correctamente.");
    }

    @Override
    public String toString() {
        return "JuegoCartas{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", categoria='" + getCategoria() + '\'' +
                ", cantidadJugadores=" + getCantidadJugadores() +
                ", cantidadCartas=" + cantidadCartas +
                '}';
    }
}
