/**
 * PRY2203 - Semana 1
 *
 * Paquete DATA:
 * contiene clases encargadas de cargar y administrar datos del ejemplo.
 *
 * En esta etapa trabajamos con datos escritos directamente en código
 * y un arreglo simple. No utilizamos base de datos.
 */
package cl.duoc.pry2203.semana1.duocplay.data;
