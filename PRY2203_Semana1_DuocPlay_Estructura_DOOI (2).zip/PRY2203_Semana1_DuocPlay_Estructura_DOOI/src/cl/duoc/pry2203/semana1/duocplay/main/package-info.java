/**
 * PRY2203 - Semana 1
 *
 * Paquete MAIN:
 * contiene el punto de entrada de la aplicación.
 *
 * Main coordina la demostración, pero evita asumir responsabilidades
 * propias del modelo o de la administración de datos.
 */
package cl.duoc.pry2203.semana1.duocplay.main;
