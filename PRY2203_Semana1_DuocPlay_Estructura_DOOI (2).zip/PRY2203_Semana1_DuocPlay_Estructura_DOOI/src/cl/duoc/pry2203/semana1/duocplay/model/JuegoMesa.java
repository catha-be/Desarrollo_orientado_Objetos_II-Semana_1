package cl.duoc.pry2203.semana1.duocplay.model;

/**
 * ============================================================
 * PRY2203 - SEMANA 1
 * CLASE BASE: JuegoMesa
 * ============================================================
 *
 * Esta clase reúne los datos y comportamientos COMUNES de todos
 * los juegos que utilizaremos en el ejemplo DuocPlay.
 *
 * CONCEPTOS PRINCIPALES:
 * - encapsulamiento;
 * - constructor;
 * - getters y setters;
 * - método común;
 * - sobrecarga;
 * - herencia;
 * - base para polimorfismo;
 * - toString().
 *
 * RELACIÓN:
 *
 * JuegoEstrategia ES UN JuegoMesa.
 * JuegoFamiliar  ES UN JuegoMesa.
 * JuegoCartas    ES UN JuegoMesa.
 *
 * Esa relación "es un" justifica el uso de herencia.
 */
public class JuegoMesa {

    // ============================================================
    // ATRIBUTOS COMUNES
    // ============================================================

    private int id;
    private String nombre;
    private String categoria;
    private int cantidadJugadores;

    // ============================================================
    // CONSTRUCTOR DE LA CLASE PADRE
    // ============================================================

    public JuegoMesa(int id, String nombre, String categoria, int cantidadJugadores) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.cantidadJugadores = cantidadJugadores;
    }

    // ============================================================
    // GETTERS
    // ============================================================

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public int getCantidadJugadores() {
        return cantidadJugadores;
    }

    // ============================================================
    // SETTERS
    // ============================================================

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setCantidadJugadores(int cantidadJugadores) {
        if (cantidadJugadores > 0) {
            this.cantidadJugadores = cantidadJugadores;
        } else {
            System.out.println("La cantidad de jugadores debe ser mayor que cero.");
        }
    }

    // ============================================================
    // MÉTODO COMÚN
    // ============================================================
    //
    // Este comportamiento es compartido.
    // Las clases hijas lo heredan sin necesidad de copiarlo.
    // ============================================================

    public void mostrarFicha() {
        System.out.println("----------------------------------------");
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Categoría: " + categoria);
        System.out.println("Cantidad de jugadores: " + cantidadJugadores);
    }

    // ============================================================
    // MÉTODO BASE
    // ============================================================
    //
    // Este método posee una implementación GENÉRICA.
    //
    // Más adelante, cada clase hija lo SOBRESCRIBE para entregar
    // su propio comportamiento.
    // ============================================================

    public void iniciarPartida() {
        System.out.println("Iniciando partida genérica de " + nombre + ".");
    }

    // ============================================================
    // SOBRECARGA DE MÉTODOS
    // ============================================================
    //
    // SOBRECARGA:
    // mismo nombre + diferente lista de parámetros.
    //
    // Tenemos tres firmas diferentes:
    //
    // iniciarPartida()
    // iniciarPartida(String nombreJugador)
    // iniciarPartida(String nombreJugador, int nivel)
    //
    // Java decide cuál ejecutar según los argumentos enviados.
    // ============================================================

    public void iniciarPartida(String nombreJugador) {
        System.out.println(nombreJugador + " inicia una partida de " + nombre + ".");
    }

    public void iniciarPartida(String nombreJugador, int nivel) {
        System.out.println(nombreJugador + " inicia " + nombre + " en nivel " + nivel + ".");
    }

    // ============================================================
    // toString()
    // ============================================================

    @Override
    public String toString() {
        return "JuegoMesa{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", categoria='" + categoria + '\'' +
                ", cantidadJugadores=" + cantidadJugadores +
                '}';
    }
}
