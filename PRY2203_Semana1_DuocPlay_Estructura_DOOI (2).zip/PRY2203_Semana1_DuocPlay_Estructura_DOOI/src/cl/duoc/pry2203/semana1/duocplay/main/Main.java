package cl.duoc.pry2203.semana1.duocplay.main;

import cl.duoc.pry2203.semana1.duocplay.data.GestorJuegos;
import cl.duoc.pry2203.semana1.duocplay.model.JuegoCartas;
import cl.duoc.pry2203.semana1.duocplay.model.JuegoEstrategia;
import cl.duoc.pry2203.semana1.duocplay.model.JuegoFamiliar;
import cl.duoc.pry2203.semana1.duocplay.model.JuegoMesa;
import cl.duoc.pry2203.semana1.duocplay.model.Jugador;

/**
 * ============================================================
 * PRY2203 - DESARROLLO ORIENTADO A OBJETOS II
 * SEMANA 1
 * MAIN GUIADO - DUOCPLAY / JUEGOS DE MESA
 * ============================================================
 *
 * PAQUETE main
 *
 * RESPONSABILIDAD:
 * Ejecutar y demostrar el funcionamiento del programa.
 *
 * Main NO debería transformarse en una clase que hace todo.
 *
 * Para mantener una estructura ordenada:
 *
 * model -> representa las entidades y reglas del dominio.
 * data  -> carga/administra los datos del ejemplo.
 * main  -> ejecuta y demuestra.
 *
 * ORDEN DE ESTUDIO:
 *
 * 1. Jugador
 * 2. JuegoMesa
 * 3. JuegoEstrategia / JuegoFamiliar / JuegoCartas
 * 4. GestorJuegos
 * 5. Main
 */
public class Main {

    public static void main(String[] args) {

        // ========================================================
        // BLOQUE 1 - REPASO: OBJETO + ENCAPSULAMIENTO
        // ========================================================

        System.out.println("\n========== 1. OBJETO Y ENCAPSULAMIENTO ==========\n");

        Jugador jugador = new Jugador("Camila", 20, 2);

        System.out.println("Objeto creado:");
        System.out.println(jugador);

        System.out.println("\nLectura mediante getter:");
        System.out.println("Nombre: " + jugador.getNombre());

        System.out.println("\nModificación mediante setter:");
        jugador.setNivel(3);
        System.out.println("Nuevo nivel: " + jugador.getNivel());

        // ========================================================
        // BLOQUE 2 - HERENCIA
        // ========================================================
        //
        // Creamos objetos de tres clases hijas distintas.
        // ========================================================

        System.out.println("\n========== 2. HERENCIA ==========\n");

        JuegoEstrategia estrategia = new JuegoEstrategia(
                201,
                "Imperio Digital",
                "Estrategia",
                4,
                "Media"
        );

        JuegoFamiliar familiar = new JuegoFamiliar(
                202,
                "Ruta Duoc",
                "Familiar",
                5,
                8
        );

        JuegoCartas cartas = new JuegoCartas(
                203,
                "Batalla de Código",
                "Cartas",
                2,
                40
        );

        // mostrarFicha() NO está escrito nuevamente en cada hijo.
        // Fue heredado desde JuegoMesa.

        estrategia.mostrarFicha();
        familiar.mostrarFicha();
        cartas.mostrarFicha();

        // ========================================================
        // BLOQUE 3 - SOBRESCRITURA
        // ========================================================
        //
        // Los tres objetos ejecutan iniciarPartida().
        //
        // El nombre y la firma son iguales.
        // Pero cada clase hija tiene su propia implementación.
        // ========================================================

        System.out.println("\n========== 3. SOBRESCRITURA ==========\n");

        estrategia.iniciarPartida();
        familiar.iniciarPartida();
        cartas.iniciarPartida();

        // ========================================================
        // BLOQUE 4 - SOBRECARGA
        // ========================================================
        //
        // Misma clase.
        // Mismo nombre de método.
        // Distintos parámetros.
        // ========================================================

        System.out.println("\n========== 4. SOBRECARGA ==========\n");

        estrategia.iniciarPartida();
        estrategia.iniciarPartida("Camila");
        estrategia.iniciarPartida("Camila", 4);

        // ========================================================
        // BLOQUE 5 - POLIMORFISMO DIRECTO
        // ========================================================
        //
        // La variable se declara como JuegoMesa.
        // El objeto real es una clase hija.
        // ========================================================

        System.out.println("\n========== 5. POLIMORFISMO DIRECTO ==========\n");

        JuegoMesa juego1 = estrategia;
        JuegoMesa juego2 = familiar;
        JuegoMesa juego3 = cartas;

        juego1.iniciarPartida();
        juego2.iniciarPartida();
        juego3.iniciarPartida();

        // PREGUNTA CLAVE:
        //
        // Si las tres variables tienen tipo JuegoMesa,
        // ¿por qué se ejecutan tres resultados diferentes?
        //
        // Respuesta:
        // por el tipo REAL de cada objeto y la sobrescritura.

        // ========================================================
        // BLOQUE 6 - SEPARACIÓN DE RESPONSABILIDADES
        // ========================================================
        //
        // Ahora Main utiliza una clase del paquete data.
        //
        // GestorJuegos se encargará de cargar y administrar
        // los objetos de prueba.
        // ========================================================

        System.out.println("\n========== 6. PAQUETE data + GESTOR ==========\n");

        GestorJuegos gestor = new GestorJuegos();
        gestor.cargarDatosIniciales();

        // ========================================================
        // BLOQUE 7 - ARREGLO POLIMÓRFICO
        // ========================================================

        System.out.println("\n========== 7. ARREGLO POLIMÓRFICO ==========\n");

        gestor.mostrarTodos();

        // ========================================================
        // BLOQUE 8 - TIPO DE REFERENCIA VS. TIPO REAL
        // ========================================================

        System.out.println("\n========== 8. REFERENCIA VS. OBJETO REAL ==========\n");

        gestor.mostrarTiposReales();

        // ========================================================
        // BLOQUE 9 - toString()
        // ========================================================

        System.out.println("\n========== 9. toString() ==========\n");

        JuegoMesa[] juegos = gestor.getJuegos();

        for (JuegoMesa juego : juegos) {
            System.out.println(juego);
        }

        // ========================================================
        // CIERRE
        // ========================================================

        System.out.println("\n========== REPASO FINAL ==========\n");

        System.out.println("""
                Después de estudiar este proyecto deberías poder explicar:

                1. ¿Qué es una clase?
                2. ¿Qué es un objeto?
                3. ¿Qué es un atributo?
                4. ¿Qué es un método?
                5. ¿Qué hace un constructor?
                6. ¿Qué significa this?
                7. ¿Qué significa private?
                8. ¿Qué es encapsulamiento?
                9. ¿Para qué sirven getter y setter?
                10. ¿Qué hace toString()?
                11. ¿Qué significa extends?
                12. ¿Qué hace super(...)?
                13. ¿Qué es herencia?
                14. ¿Qué es sobrescritura?
                15. ¿Para qué sirve @Override?
                16. ¿Qué es sobrecarga?
                17. ¿Qué es polimorfismo?
                18. ¿Qué diferencia existe entre tipo de referencia
                    y tipo real del objeto?
                19. ¿Por qué un arreglo JuegoMesa[] puede contener
                    objetos de distintas clases hijas?
                20. ¿Qué responsabilidad tienen model, data y main?
                """);
    }
}
