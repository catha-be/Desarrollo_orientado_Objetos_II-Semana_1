package cl.duoc.pry2203.semana1.duocplay.model;

/**
 * ============================================================
 * PRY2203 - SEMANA 1
 * CLASE HIJA: JuegoEstrategia
 * ============================================================
 *
 * extends JuegoMesa significa que JuegoEstrategia HEREDA de
 * JuegoMesa.
 *
 * La clase hija reutiliza los atributos y métodos comunes y puede
 * agregar datos y comportamientos específicos.
 */
public class JuegoEstrategia extends JuegoMesa {

    // Atributo propio de esta clase hija.
    private String dificultad;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================
    //
    // super(...) llama al constructor de la clase padre.
    //
    // Así evitamos repetir la inicialización de:
    // id, nombre, categoría y cantidad de jugadores.
    // ============================================================

    public JuegoEstrategia(
            int id,
            String nombre,
            String categoria,
            int cantidadJugadores,
            String dificultad
    ) {
        super(id, nombre, categoria, cantidadJugadores);
        this.dificultad = dificultad;
    }

    public String getDificultad() {
        return dificultad;
    }

    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }

    // ============================================================
    // SOBRESCRITURA
    // ============================================================
    //
    // @Override indica que estamos redefiniendo el método
    // iniciarPartida() heredado desde JuegoMesa.
    //
    // MISMO NOMBRE.
    // MISMOS PARÁMETROS.
    // DISTINTO COMPORTAMIENTO.
    // ============================================================

    @Override
    public void iniciarPartida() {
        System.out.println("Preparando tablero estratégico de "
                + getNombre()
                + ". Dificultad: "
                + dificultad + ".");
    }

    // Método propio de JuegoEstrategia.
    public void analizarEstrategia() {
        System.out.println("Analizando estrategia inicial de " + getNombre() + ".");
    }

    @Override
    public String toString() {
        return "JuegoEstrategia{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", categoria='" + getCategoria() + '\'' +
                ", cantidadJugadores=" + getCantidadJugadores() +
                ", dificultad='" + dificultad + '\'' +
                '}';
    }
}
