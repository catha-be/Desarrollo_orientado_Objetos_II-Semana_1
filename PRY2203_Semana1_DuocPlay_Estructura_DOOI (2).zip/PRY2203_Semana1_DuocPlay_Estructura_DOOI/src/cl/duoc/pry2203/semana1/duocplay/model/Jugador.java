package cl.duoc.pry2203.semana1.duocplay.model;

/**
 * ============================================================
 * PRY2203 - DESARROLLO ORIENTADO A OBJETOS II
 * SEMANA 1 - REPASO BASE DE POO
 * EJEMPLO PARALELO DEL PROFESOR: DUOCPLAY / JUEGOS DE MESA
 * ============================================================
 *
 * CLASE: Jugador
 *
 * ¿PARA QUÉ EXISTE ESTA CLASE?
 * Sirve como repaso de los conceptos más básicos de Programación
 * Orientada a Objetos antes de trabajar herencia y polimorfismo.
 *
 * AQUÍ PRACTICAMOS:
 * - clase;
 * - atributos;
 * - encapsulamiento;
 * - constructor;
 * - this;
 * - getters;
 * - setters;
 * - validaciones simples;
 * - toString().
 *
 * IMPORTANTE:
 * Este proyecto es un EJEMPLO PARALELO.
 * No corresponde a la solución de la actividad oficial SpeedFast.
 */
public class Jugador {

    // ============================================================
    // 1. ATRIBUTOS ENCAPSULADOS
    // ============================================================
    //
    // private significa que estos atributos pertenecen al estado
    // interno del objeto y no deben modificarse directamente
    // desde otras clases.
    //
    // Esto es ENCAPSULAMIENTO.
    // ============================================================

    private String nombre;
    private int edad;
    private int nivel;

    // ============================================================
    // 2. CONSTRUCTOR
    // ============================================================
    //
    // El constructor se utiliza cuando creamos un objeto.
    //
    // Ejemplo:
    // new Jugador("Camila", 20, 2);
    //
    // this.nombre representa el atributo del objeto actual.
    // nombre representa el parámetro recibido.
    // ============================================================

    public Jugador(String nombre, int edad, int nivel) {
        this.nombre = nombre;
        this.edad = edad;
        this.nivel = nivel;
    }

    // ============================================================
    // 3. GETTERS
    // ============================================================
    //
    // Permiten CONSULTAR atributos privados.
    // ============================================================

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getNivel() {
        return nivel;
    }

    // ============================================================
    // 4. SETTERS
    // ============================================================
    //
    // Permiten MODIFICAR atributos privados de forma controlada.
    // Además, podemos agregar validaciones.
    // ============================================================

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        if (edad >= 0) {
            this.edad = edad;
        } else {
            System.out.println("La edad no puede ser negativa.");
        }
    }

    public void setNivel(int nivel) {
        if (nivel >= 1) {
            this.nivel = nivel;
        } else {
            System.out.println("El nivel debe ser 1 o superior.");
        }
    }

    // ============================================================
    // 5. toString()
    // ============================================================
    //
    // Todas las clases Java heredan de Object.
    // Object posee un método llamado toString().
    //
    // Aquí lo SOBRESCRIBIMOS para devolver información útil.
    // ============================================================

    @Override
    public String toString() {
        return "Jugador{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", nivel=" + nivel +
                '}';
    }
}
