package cl.duoc.pry2203.semana1.duocplay.data;

import cl.duoc.pry2203.semana1.duocplay.model.JuegoCartas;
import cl.duoc.pry2203.semana1.duocplay.model.JuegoEstrategia;
import cl.duoc.pry2203.semana1.duocplay.model.JuegoFamiliar;
import cl.duoc.pry2203.semana1.duocplay.model.JuegoMesa;

/**
 * ============================================================
 * PRY2203 - SEMANA 1
 * PAQUETE: data
 * CLASE: GestorJuegos
 * ============================================================
 *
 * ¿POR QUÉ TENEMOS UN PAQUETE data?
 *
 * Para continuar con una estructura semejante a la trabajada
 * previamente en Desarrollo Orientado a Objetos I.
 *
 * RESPONSABILIDAD DE ESTA CLASE:
 * - crear/cargar datos de ejemplo;
 * - mantener los juegos del ejemplo;
 * - realizar operaciones simples con ellos;
 * - evitar que Main tenga toda la lógica.
 *
 * IMPORTANTE:
 * Esta separación es una RECOMENDACIÓN DOCENTE de organización.
 * No es un requisito obligatorio de la actividad oficial Semana 1.
 *
 * En esta semana NO utilizaremos List ni ArrayList.
 * Usaremos un arreglo simple de JuegoMesa para concentrarnos en:
 * herencia + sobrescritura + polimorfismo.
 */
public class GestorJuegos {

    // ============================================================
    // ARREGLO POLIMÓRFICO
    // ============================================================
    //
    // El arreglo está declarado como JuegoMesa[].
    //
    // Gracias a la herencia puede almacenar:
    // - JuegoEstrategia;
    // - JuegoFamiliar;
    // - JuegoCartas.
    //
    // Esto permite observar polimorfismo sin introducir todavía
    // colecciones genéricas.
    // ============================================================

    private JuegoMesa[] juegos;

    public GestorJuegos() {
        // Inicialmente reservamos espacio para tres juegos.
        juegos = new JuegoMesa[3];
    }

    // ============================================================
    // CARGA DE DATOS
    // ============================================================
    //
    // Los datos están definidos en código porque el objetivo de
    // Semana 1 es estudiar POO, no lectura de archivos ni BD.
    // ============================================================

    public void cargarDatosIniciales() {

        juegos[0] = new JuegoEstrategia(
                101,
                "Reinos en Conflicto",
                "Estrategia",
                4,
                "Alta"
        );

        juegos[1] = new JuegoFamiliar(
                102,
                "Rally en Familia",
                "Familiar",
                6,
                8
        );

        juegos[2] = new JuegoCartas(
                103,
                "Duelo de Magos",
                "Cartas",
                2,
                60
        );
    }

    // ============================================================
    // GETTER DEL ARREGLO
    // ============================================================
    //
    // Nos permite obtener los juegos desde Main cuando queramos
    // demostrar una operación específica.
    // ============================================================

    public JuegoMesa[] getJuegos() {
        return juegos;
    }

    // ============================================================
    // MOSTRAR TODOS
    // ============================================================
    //
    // Aquí ocurre POLIMORFISMO:
    //
    // "juego" es una referencia de tipo JuegoMesa.
    // Sin embargo, el objeto real puede ser una de sus subclases.
    //
    // Al ejecutar juego.iniciarPartida(), Java determina qué
    // implementación sobrescrita corresponde al objeto real.
    // ============================================================

    public void mostrarTodos() {

        for (JuegoMesa juego : juegos) {

            juego.mostrarFicha();

            // MISMA llamada:
            juego.iniciarPartida();

            // Distinto resultado según el objeto real.
            System.out.println();
        }
    }

    // ============================================================
    // MÉTODO DE APOYO PARA OBSERVAR EL TIPO REAL
    // ============================================================
    //
    // getClass().getSimpleName() no es el objetivo central de la
    // semana, pero resulta útil para observar qué clase concreta
    // fue creada.
    // ============================================================

    public void mostrarTiposReales() {

        for (JuegoMesa juego : juegos) {
            System.out.println(
                    "Referencia general: JuegoMesa"
                            + " | Objeto real: "
                            + juego.getClass().getSimpleName()
                            + " | Nombre: "
                            + juego.getNombre()
            );
        }
    }
}
